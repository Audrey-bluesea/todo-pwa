/**
 * push-manage —— HTTP 触发函数
 * 接收前端排程/取消请求，写入/删除云数据库 reminders 集合。
 * 前端调用：POST {BASE}/push-manage  body: { action: 'schedule'|'cancel', ... }
 */
const tcb = require('@cloudbase/node-sdk');
const app = tcb.init({}); // 云函数内自动识别当前环境
const db = app.database();

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function res(statusCode, obj) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', ...cors },
    body: JSON.stringify(obj),
  };
}

exports.main = async (event) => {
  if (event.httpMethod === 'OPTIONS') return res(204, {});
  if (event.httpMethod !== 'POST') return res(405, { ok: false, error: 'method-not-allowed' });

  // 确保 reminders 集合存在（幂等：已存在时 createCollection 会报错，忽略即可）
  try { await db.createCollection('reminders'); } catch (e) { /* 已存在则忽略 */ }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return res(400, { ok: false, error: 'bad-json' });
  }

  const { action, tag } = body;

  try {
    if (action === 'cancel') {
      if (!tag) return res(400, { ok: false, error: 'bad-payload' });
      await db.collection('reminders').doc(tag).remove().catch(() => {});
      return res(200, { ok: true });
    }

    if (action === 'schedule') {
      const { subscription, fireAt, title, body: pushBody } = body;
      if (!subscription || !subscription.endpoint || !fireAt || !tag) {
        return res(400, { ok: false, error: 'bad-payload' });
      }
      // 以 tag(=todo.id) 为 _id 做 upsert：重复保存同一任务只会更新触发时间
      // 注意：.doc(tag) 已经指定了文档 ID，set 的数据里不能再包含 _id 字段
      await db.collection('reminders').doc(tag).set({
        tag,
        subscription,
        fireAt,
        title: title || '待办提醒',
        body: pushBody || '',
        status: 'pending',
        updatedAt: Date.now(),
      });
      return res(200, { ok: true });
    }

    return res(400, { ok: false, error: 'unknown-action' });
  } catch (e) {
    console.error('[push-manage] error', e);
    return res(500, { ok: false, error: String(e) });
  }
};
